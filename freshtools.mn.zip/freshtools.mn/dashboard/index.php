<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#000000">
    <meta name="keywords" content="Buy Spamming Tools | Fresh SMTP Shop | Buy Inbox Mailer | Buy Spam Tools | Buy Paid Account | Buy Fresh RDP | Rdp Shop | Fresh Spam Shop | buy Fresh Smtp | Fresh Shell | Fresh Smtp | Fresh Office365 smtp | Paid Date Account| Spam Tools | SMTP | SHELL | MAILER | cPanel | FTP | Combo List | Fresh RDP | Fresh Tools | Valid shod | spammer shop | Fresh Cpanel , Fresh Shell, Hacking RDP , Hacking shop , Buy Spamming Tools | Spammer Tools | Inbox Mailer | Buy Tools Spam | Spamming Tools | Rdp Shop | Site To Buy Spamming Tools | Buy Spamm Equipments | Buy Carding Accounts |FreshTools,Spam Tools,SMTP,SHELL,MAILER,cPanel,FTP,Combo List,Fresh RDP,Fresh Tools,Valid shod,spammer shop,Fresh Cpanel">
    <meta name="description" content="Buy Spamming Tools | Fresh SMTP Shop | Buy Inbox Mailer | Buy Spam Tools | Buy Paid Account | Buy Fresh RDP | Rdp Shop | Fresh Spam Shop | buy Fresh Smtp | Fresh Shell | Fresh Smtp | Fresh Office365 smtp | Paid Date Account| Spam Tools | SMTP | SHELL | MAILER | cPanel | FTP | Combo List | Fresh RDP | Fresh Tools | Valid shod | spammer shop | Fresh Cpanel , Fresh Shell, Hacking RDP , Hacking shop , Buy Spamming Tools | Spammer Tools | Inbox Mailer | Buy Tools Spam | Spamming Tools | Rdp Shop | Site To Buy Spamming Tools | Buy Spamm Equipments | Buy Carding Accounts |FreshTools,Spam Tools,SMTP,SHELL,MAILER,cPanel,FTP,Combo List,Fresh RDP,Fresh Tools,Valid shod,spammer shop,Fresh Cpanel">
    <link rel="apple-touch-icon" href="../logo192.png">
    <link rel="manifest" href="../manifest.json">
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Lato">
    <link href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" rel="stylesheet">
    <title>FreshTools | Spam Tools | SMTP | SHELL | MAILER | cPanel | FTP | Combo List | Fresh RDP | Fresh Tools | Valid shod | spammer shop | Fresh Cpanel , Fresh Shell, Hacking RDP , Hacking shop , Buy Spamming Tools | Spammer Tools | Inbox Mailer | Buy Tools Spam | Spamming Tools | Rdp Shop | Site To Buy Spamming Tools | Buy Spamm Equipments | Buy Carding Accounts |</title>
    <link href="../css/styles.css" rel="stylesheet">
    <script charset="utf-8" src="../js/script1.js"></script><script charset="utf-8" src="../js/script2.js"></script><script charset="utf-8" src="../js/24.5bf4e7b1.chunk.js"></script><script charset="utf-8" src="../js/27.7e940a6d.chunk.js"></script><script charset="utf-8" src="../js/25.23ed498c.chunk.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/loader.js"></script>
    <link id="load-css-0" rel="stylesheet" type="text/css" href="https://www.gstatic.com/charts/49/css/core/tooltip.css">
    <link id="load-css-1" rel="stylesheet" type="text/css" href="https://www.gstatic.com/charts/49/css/util/util.css">
    <link id="load-css-2" rel="stylesheet" type="text/css" href="https://www.gstatic.com/charts/49/css/controls/controls.css">
    <script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_default_module.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_graphics_module.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_ui_module.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_corechart_module.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_controls_module.js"></script>
</head>
<body style="height:100%">
<div style="height:100%" id="root">
<div class="userPanelBackground" style="">
<div class="header  card">
    <div class="p-0 m-0 card-body">
        <div class="p-0 m-0 header-container row">
            <div class="col-lg-7">
            <ul class="header-nav">
                <a href="index.php" class="navbar-brand">FreshTools</a>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="hostDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-server"></i><span>Hosts</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="hostDropDown">
                        <li><a href="rdp.php"><i class="fa fa-desktop fa-fw"></i><span>Rdps</span><span class="badge badge-light">781</span></a></li>
                        <li><a href="cpanel.php"><i class="fas fa-tools fa-fw"></i><span>Cpanel</span><span class="badge badge-light">1009</span></a></li>
                        <li><a href="ssh.php"><i class="fa fa-terminal fa-fw"></i><span>SSH</span><span class="badge badge-light">555</span></a></li>
                        <li><a href="shell.php"><i class="fa fa-file-code-o fa-fw"></i><span>Shells</span><span class="badge badge-light">27435</span></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="sendDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-mail-bulk"></i><span>Send</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="sendDropDown">
                        <li><a href="webmail.php"><i class="flaticon-inbox"></i><span>Webmail</span><span class="badge badge-light">19924</span></a></li>
                        <li><a href="phpmailers.php"><i class="fas fa-leaf fa-fw"></i><span>Php Mailers</span><span class="badge badge-light">26582</span></a></li>
                        <li><a href="smtp.php"><i class="fas fa-envelope fa-fwl"></i><span>Smtps</span><span class="badge badge-light">35941</span></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="leadDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-address-book"></i><span>Leads</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="leadDropDown">
                        <li><a href="leads.php"><i class="fas fa-at fa-fw"></i><span>Leads</span><span class="badge badge-light">6738</span></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="leadDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-users"></i><span>Accounts</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="leadDropDown">
                        <li><a href="accounts.php"><i class="fa fa-users"></i><span>Account</span><span class="badge badge-light" style="margin-top: 4px;">5962</span></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="leadDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user-secret"></i><span>Vip</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="leadDropDown">
                        <li><a href="vip.php"><i class="fa fa-user-secret"></i><span>Other</span><span class="badge badge-light" style="margin-top: 4px;">30</span></a></li>
                        <li><a href="bankaccount.php"><i class="fa fa-university"></i><span>Bank Account</span><span class="badge badge-light" style="margin-top: 4px;">5</span></a></li>
                        <li><a href="fullz.php"><i class="fa fa-university"></i><span>CC / Fullz</span><span class="badge badge-light" style="margin-top: 4px;">0</span></a></li>
                    </ul>
                </li>
            </ul>
            </div>
            <div class="col-lg-5">
            <ul dir="ltr" class="header-nav right-nav">
                <li class="dropdown">
                    <a class="dropdown-toggle" href="#" id="AccountDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>My Account</span><i class="fas fa-user"></i></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="AccountDropDown">
                        <li><a href="profile.php"><span>Setting</span><i class="fas fa-user-cog fa-fw"></i></a></li>
                        <li><a href="orders.php"><span>My Orders</span><i class="fas fa-shopping-cart fa-fw"></i></a></li>
                        <li><a href="addbalance.php"><span>Add Balance</span><i class="fas fa-dollar-sign fa-fw"></i></a></li>
                        <li><a href="notification.php"><span>Inbox</span><i class="fas fa-inbox fa-fw"></i></a></li>
                        <li><a href="logout.php"><span>Logout</span><i class="fas fa-sign-out-alt fa-fw"></i></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="TicketDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Ticket</span><i class="fas fa-inbox"></i></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="TicketDropDown">
                        <li><a href="tickets.php"><span>Ticket</span><i class="fas fa-comments fa-fw"></i><span class="badge badge-light">0</span></a></li>
                        <li><a href="reports.php"><span>reports</span><i class="fas fa-flag fa-fw"></i><span class="badge badge-light">0</span></a></li>
                    </ul>
                </li>
                <li><a class="add-balance" href="addbalance.php"><i class="fas fa-plus-circle"></i><span>0.00</span></a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bell" style="font-size: 16px; margin-right: 5px; color: rgb(255, 255, 255);"></i><span class="notification-badge badge badge-danger" style="margin-top: -5px;">0</span></a>
                    <ul class="dropdown-menu header-nav drop-nav notificationList" aria-labelledby="notification">
                        <li>No notification</li>
                    </ul>
                </li>
            </ul>
            </div>
        </div>
    </div>
</div><noscript>You need to enable JavaScript to run this app.</noscript>

<div>
    <div class="mainContainer">
        <div class="row">
            <div class="col-lg-7">
            <div class="dashboard-info alert ">
                <p style="margin-bottom: 0px;">Hello <span class="badge badge-dark">wdsujanray</span></p>
                <p style="margin-bottom: 0px;">Your Rate is : <span class="badge badge-success">0 <i class="fa fa-star" style="color: yellow;"></i> </span></p>
                <p style="margin-bottom: 0px;">If you have any <b>Question</b> ,<b>Problem</b>, <b>Suggestion</b> or <b>Request</b> Please feel free to<a href="addticket.php" class="btn  btn btn-default btn-xs ticket-btn"><i class="fa fa-edit"></i>  Open a Ticket</a></p>
                <p>if you want to report an order , just go to<a href="#" style="margin-left: 3px; margin-right: 3px;"><abbr title="Account - > My Orders or Click here"><span>My Orders</span> <i class="fa fa-shopping-cart"></i></abbr></a>then click on  <span class="badge badge-dark">Report #ID</span> button</p>
                <br>
                <p>Our Domains are <b>  freshtools.net</b><b>  ||  https://t.me/freshto0ls</b> - Please Save them! </p>
            </div>
            <ul class="list-group">
                <h4><i class="fa fa-info-circle"></i> News</h4>
                <li class="news-list list-group-item">
                    <p class="title">Hacked Cpanel</p>
                    <div>
                        <p><strong>Hello Guys</strong></p>
                        <p><strong>today we have Gift for Freshtools members .</strong></p>
                        <p><span style="color: rgb(184,49,47);">1000 Free Hacked Cpanel</span></p>
                        <p><span style="color: rgb(184,49,47);"><strong>download link</strong></span></p>
                        <p><strong>https://mega.nz/file/YQ5DjAoC#1gvL48PJLR_7y-bjowviF27-ovyntBUWnSyegASNlEM</strong></p>
                        <p><strong>Enjoy</strong></p>
                        <p><a href="https://t.me/freshto0ls" target="_self"><strong>Tellegram channel</strong></a>&nbsp;</p>
                        <p><a href="https://icq.im/AoLFhugyvFzOUo7ob3g" target="_self">ICQ channel</a>&nbsp;</p>
                    </div>
                    <p class="date" id="todayDate">2020-10-31</p>
                </li>
                <li class="news-list list-group-item">
                    <p class="title">Score System!</p>
                    <div>
                        <p>Today We have a good News for you&nbsp;</p>
                        <p>Our Shop is Upgraded to User Score System!</p>
                        <p>From Now On, if you don't send Report for each Bought , You Will Receive <span style="color: rgb(184,49,47);"><strong>10 Bonus Score</strong></span> !!</p>
                        <p><strong>If your Score Reaches 1000 , We will Fund </strong><span style="color: rgb(184,49,47);"><strong>20$</strong></span><strong> as Bonus .</strong></p>
                        <p><span style="color: rgb(184,49,47);">Then before Sending any Report , exactly check your tools Healthy, to get More Score and Get Funds .</span></p>
                        <p>and You can see your Score Rate in top of Account.</p>
                    </div>
                    <p class="date" id="previousDate">2020-09-14</p>
                </li>
                <li class="news-list list-group-item">
                    <p class="title">Sendgrid and Amazon SMTP</p>
                    <div>
                        <p><span style="color: rgb(209,72,65);"><strong>Hello Guys sendgrid and Amazon Pro Added on Vip Section</strong></span></p>
                        <p>✅ full information&nbsp;</p>
                        <p>✅ Inbox delivery</p>
                        <p>✅ Smtp connection&nbsp;</p>
                        <p>✅ Billing information&nbsp;</p>
                        <p>✅ High limit per day.</p>
                        <p><span style="color: rgb(209,72,65);">Strat 40K - 13 million </span></p>
                    </div>
                    <p class="date" id="dayBeforeYesterdayDate">2020-09-23</p>
                </li>
            </ul>
            </div>
            <div class="col-lg-5">
            <div style="height: 290px; width: 100%;">
                <div id="reactgooglegraph-1" class="" style="height: 290px; width: 100%;">
                    <div style="position: relative;">
                        <div dir="ltr" style="position: relative; width: 499px; height: 290px;">
                        <div aria-label="A chart." style="position: absolute; left: 0px; top: 0px; width: 100%; height: 100%;">
                            <svg width="499" height="290" aria-label="A chart." style="overflow: hidden;">
                                <defs id="_ABSTRACT_RENDERER_ID_0"></defs>
                                <g>
                                    <text text-anchor="start" x="0" y="18.7" font-family="Arial" font-size="12" font-weight="bold" stroke="none" stroke-width="0" fill="#2d3e50">Available Tools !</text>
                                    <rect x="0" y="8.5" width="499" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                </g>
                                <g>
                                    <rect x="327" y="29" width="172" height="164" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g column-id="cpanel">
                                    <rect x="327" y="29" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="39.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">cpanel</text>
                                    </g>
                                    <circle cx="333" cy="35" r="6" stroke="none" stroke-width="0" fill="#476481"></circle>
                                    </g>
                                    <g column-id="rdps">
                                    <rect x="327" y="48" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="58.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">rdps</text>
                                    </g>
                                    <circle cx="333" cy="54" r="6" stroke="none" stroke-width="0" fill="#3e5871"></circle>
                                    </g>
                                    <g column-id="shells">
                                    <rect x="327" y="67" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="77.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">shells</text>
                                    </g>
                                    <circle cx="333" cy="73" r="6" stroke="none" stroke-width="0" fill="#354b60"></circle>
                                    </g>
                                    <g column-id="Ssh(Vps)">
                                    <rect x="327" y="86" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="96.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">Ssh(Vps)</text>
                                    </g>
                                    <circle cx="333" cy="92" r="6" stroke="none" stroke-width="0" fill="#2c3e50"></circle>
                                    </g>
                                    <g column-id="Smtp">
                                    <rect x="327" y="105" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="115.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">Smtp</text>
                                    </g>
                                    <circle cx="333" cy="111" r="6" stroke="none" stroke-width="0" fill="#233140"></circle>
                                    </g>
                                    <g column-id="phpMailers">
                                    <rect x="327" y="124" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="134.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">phpMailers</text>
                                    </g>
                                    <circle cx="333" cy="130" r="6" stroke="none" stroke-width="0" fill="#1a252f"></circle>
                                    </g>
                                    <g column-id="leads">
                                    <rect x="327" y="143" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="153.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">leads</text>
                                    </g>
                                    <circle cx="333" cy="149" r="6" stroke="none" stroke-width="0" fill="#11181f"></circle>
                                    </g>
                                    <g column-id="webMail">
                                    <rect x="327" y="162" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="172.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">webMail</text>
                                    </g>
                                    <circle cx="333" cy="168" r="6" stroke="none" stroke-width="0" fill="#476481"></circle>
                                    </g>
                                    <g column-id="account">
                                    <rect x="327" y="181" width="172" height="12" stroke="none" stroke-width="0" fill-opacity="0" fill="#ffffff"></rect>
                                    <g>
                                        <text text-anchor="start" x="344" y="191.2" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#222222">account</text>
                                    </g>
                                    <circle cx="333" cy="187" r="6" stroke="none" stroke-width="0" fill="#3e5871"></circle>
                                    </g>
                                </g>
                                <g>
                                    <path d="M154,98.6L154,29A116,116,0,0,1,159.8841846094021,29.149335904007543L156.35367384376084,98.65973436160301A46.400000000000006,46.400000000000006,0,0,0,154,98.6" stroke="#ffffff" stroke-width="1" fill="#476481"></path>
                                </g>
                                <g>
                                    <path d="M156.35367384376084,98.65973436160301L159.8841846094021,29.149335904007543A116,116,0,0,1,164.42912227614826,29.469772749513083L158.1716489104593,98.78790909980523A46.400000000000006,46.400000000000006,0,0,0,156.35367384376084,98.65973436160301" stroke="#ffffff" stroke-width="1" fill="#3e5871"></path>
                                </g>
                                <g>
                                    <path d="M158.1716489104593,98.78790909980523L164.42912227614826,29.469772749513083A116,116,0,0,1,269.40967258658316,133.31208002005147L200.16386903463325,140.3248320080206A46.400000000000006,46.400000000000006,0,0,0,158.1716489104593,98.78790909980523" stroke="#ffffff" stroke-width="1" fill="#354b60"></path>
                                    <text text-anchor="start" x="200.8153208733653" y="86.20162438596692" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#ffffff">shells</text>
                                </g>
                                <g>
                                    <path d="M200.16386903463325,140.3248320080206L269.40967258658316,133.3120800200515A116,116,0,0,1,269.6909236149607,136.53771939029858L200.2763694459843,141.61508775611944A46.400000000000006,46.400000000000006,0,0,0,200.16386903463325,140.3248320080206" stroke="#ffffff" stroke-width="1" fill="#2c3e50"></path>
                                </g>
                                <g>
                                    <path d="M140.29416046413448,100.67043917861236L119.73540116033621,34.1760979465309A116,116,0,0,1,154,29L154,98.6A46.400000000000006,46.400000000000006,0,0,0,140.29416046413448,100.67043917861236" stroke="#ffffff" stroke-width="1" fill="#3e5871"></path>
                                </g>
                                <g>
                                    <path d="M109.26699628546757,132.67448262036726L42.167490713668954,114.18620655091813A116,116,0,0,1,119.73540116033621,34.1760979465309L140.29416046413448,100.67043917861236A46.400000000000006,46.400000000000006,0,0,0,109.26699628546757,132.67448262036726" stroke="#ffffff" stroke-width="1" fill="#476481"></path>
                                    <text text-anchor="start" x="72.08883690713614" y="91.1175424880236" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#ffffff">webMail</text>
                                </g>
                                <g>
                                    <path d="M107.71370828047394,148.2464132292322L38.284270701184866,153.11603307308047A116,116,0,0,1,42.167490713668954,114.18620655091813L109.26699628546757,132.67448262036726A46.400000000000006,46.400000000000006,0,0,0,107.71370828047394,148.2464132292322" stroke="#ffffff" stroke-width="1" fill="#11181f"></path>
                                    <text text-anchor="start" x="51.061580146972574" y="140.37833618780095" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#ffffff">leads</text>
                                </g>
                                <g>
                                    <path d="M146.43199644534238,190.77865574912275L135.07999111335596,259.4466393728069A116,116,0,0,1,38.284270701184866,153.11603307308047L107.71370828047394,148.2464132292322A46.400000000000006,46.400000000000006,0,0,0,146.43199644534238,190.77865574912275" stroke="#ffffff" stroke-width="1" fill="#1a252f"></path>
                                    <text text-anchor="start" x="67.56234928029187" y="201.03193354936127" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#ffffff">phpMailers</text>
                                </g>
                                <g>
                                    <path d="M200.2763694459843,141.6150877561194L269.6909236149607,136.53771939029855A116,116,0,0,1,135.07999111335596,259.4466393728069L146.43199644534238,190.77865574912275A46.400000000000006,46.400000000000006,0,0,0,200.2763694459843,141.6150877561194" stroke="#ffffff" stroke-width="1" fill="#233140"></path>
                                    <text text-anchor="start" x="200.643770169275" y="215.617591612235" font-family="Arial" font-size="12" stroke="none" stroke-width="0" fill="#ffffff">Smtp</text>
                                </g>
                                <g></g>
                            </svg>
                            <div aria-label="A tabular representation of the data in the chart." style="position: absolute; left: -10000px; top: auto; width: 1px; height: 1px; overflow: hidden;">
                                <table>
                                    <thead>
                                    <tr>
                                        <th>title</th>
                                        <th>ddd</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>cpanel</td>
                                        <td>1,009</td>
                                    </tr>
                                    <tr>
                                        <td>rdps</td>
                                        <td>781</td>
                                    </tr>
                                    <tr>
                                        <td>shells</td>
                                        <td>27,435</td>
                                    </tr>
                                    <tr>
                                        <td>Ssh(Vps)</td>
                                        <td>555</td>
                                    </tr>
                                    <tr>
                                        <td>Smtp</td>
                                        <td>35,941</td>
                                    </tr>
                                    <tr>
                                        <td>phpMailers</td>
                                        <td>26,582</td>
                                    </tr>
                                    <tr>
                                        <td>leads</td>
                                        <td>6,738</td>
                                    </tr>
                                    <tr>
                                        <td>webMail</td>
                                        <td>19,924</td>
                                    </tr>
                                    <tr>
                                        <td>account</td>
                                        <td>5,962</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        </div>
                        <div aria-hidden="true" style="display: none; position: absolute; top: 300px; left: 509px; white-space: nowrap; font-family: Arial; font-size: 12px;">account</div>
                        <div></div>
                    </div>
                </div>
            </div>
            <br>
            <div class="alert dashboard-info">
                <h4>Need Help ? Our Support team is here !</h4>
                <a href="addticket.php" class="btn  btn btn-default btn-xs "><i class="fa fa-edit"></i>  Open a Ticket</a>
                <h5 style="margin-top: 15px;"><b>Available Payment Method :</b> </h5>
                <div class="row payment_method"><a href="addbalance.php">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADEAAAAwCAYAAAC4wJK5AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NDkxMSwgMjAxMy8xMC8yOS0xMTo0NzoxNiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpEOUE5NjMzNUU0OUExMUUzOUZEOUM5QzFGMjAxQzdFOSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpEOUE5NjMzNkU0OUExMUUzOUZEOUM5QzFGMjAxQzdFOSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkQ5QTk2MzMzRTQ5QTExRTM5RkQ5QzlDMUYyMDFDN0U5IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkQ5QTk2MzM0RTQ5QTExRTM5RkQ5QzlDMUYyMDFDN0U5Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+iu0OuQAABhVJREFUeNrcWmtsVEUU/na7bWlht+3uVlDEYqVBAxSwIYogj6o8lEBQUKElbflhfMTaaKIm4iMRMWqUGEI02tBCkYcioEQEjFR5iTFASwtWJGB5WGi326d90O6OZ+7M7vbS7t7bdhcWTvK1s3Nn7sx3z5k5Zx4GR8QgBEFMhPsJDxDGEEYSbiPwl8cRGgjNhH8JfxHKCQcJhwmd/W3c0E8SUwjZhPmE+D7UrydsJxQQ9l1LEgbC44RlhHEInvxBWEH4jsBCSWI0YbXUQKhkP+F5aXK6xNiLcvzLHwsxAS4PynZek1oPiib4wNxEmIVrLz8QFhGa+qOJwXLAXQ8CXB4jFMt+9IlEIuFnQiqur6QRfpIW0SsSAwg7CKMQHsJ9zy7ZL90kPiHch/AS7kxX6iWxgPAcwlOelf0LODtZCBWEWxG+UkW4m9DoTxNvhzkByP69408TfBo7S4hB+EsrIZlw6WpNvHSDEIDsZ97V5sRD6ZyeSkcnJcNWkA9rR6MCm+M8bHt3+VC8G9aX8xBhtqrqWV98AbZL/3jrJeTl6ogfjLCdKhN1Wp2wrfkyUOks2W+AmxNhNoEFAivazNxuN2P7DqryW9KmMFZaxljleSXd9Vm9bThjp06LeiXHmVYbbelzlLJK+RUfa5aX/fZqYo7mV6qs7DG7peQo2l95A2zYUMRs/Uqlkc56B3CxSkmz1NGIHTs+YBPR2Zne9JX9B/SGJV4S6f0x0ObivTCUnVCIWBbOuyp4scFw6HdhyFmL/b4jIpaiiqmTYDhZISxrQKyeptM9JOLlvNs/OXdRDLKkYep8ixmdq78Q6UULyOyjeqxuzlhIgc6PNN/UiPfYEvS0eg/vvzEoBJSA3dxzPq3RGr/dAUNdPZjdBvOc2T1rYsnTaF1TBNQ5BQlrgt6WR3ISI4JCIukO5V9HSZmvYxYb4HSCudqAzVuVvMjs7iY1IGUk/YlGSymthWpqhTkl6CaRYuzjAl9tMfPnK+PBcO4CGrdt8+ZHDrYDtfXCO/GvzGXmQzDF21X1B+YsASvaJH44hSZwi11v84o56VpkuyvPw7D/EHD8hCo/YWkOIvNXKQRan8hUR5dkPrhcLWaxY0dgKD8JFhUFc9aiLr4hgkK6eWhct1m046yTjka3Jswmv9MdObnI5OGIvDNJDNYpk8SD1FGKg1PMffJEhRhb/hEa8ovganKqN6OGUCRTW+sbHus2Ah++C2PmU8Cnq5S8QTNnAEdL0NngECRqHIhQvq9+AzHJTa1u0l55RoGyOOSNTU+HMT4OnWcrFd+ga3eBNMFqary/G9duQtx7b4GNS0XMmLFoLSsl37AY7YUbfBqvdQoSdqteDk1GuYGlKdHTJsP09VrErHxf9xcyko9wVzt8zs95GdgjvkpsVgZMcWT348eiefcebxmXHNiw6SZRz0mcDlWUZrDbyTxqVXkdhetFYvECWJZmAN9sJztz+Yg6RHmm35xOm+QiKDQyOBEup3qcNH2/E1bqKEu0w7DsVTRPmKZ63iknAj7lGmPMcLc2abVS4TGn0BAZkQyjxaL2fe4rwMYt4sfxcrSf+Vv9vOOKz4RT7tJq4U+POQHe4RvImSWpnJrmGEpOAWgAR+VkdA8aC4RJudZu6L5QSEvzpcmnaEhx11D8UX/hblNyqjcM94bJFI63PTzXb4jseiaXsapLvvIHDyvvUYX2vx5gzoFDuterrvHVa29nrGC9ZijuWZ7ysXFBa6ctzISmOtzOh5HHnPhBRyFuLCmU/b75Ngq4ej67QbTwuYfATbt5xh/khrkWcrsS8LcXu0WqK1zNaIvWXqx3sUX4BeG1M853G3iM0tYt0PRTgRecSSgLEwK8H7N6IhCIBBd+gD4jDIgcITwSaMmgdWbHpzF+mrnrOhHYSZgup3/0lYRHI3yH8E0E4QqDTuHtvC7b1YzF9Z5j81XLcsIEiPsYoRR+GH8v4QPovFlg7GUDJRCXUJ6U6WDbPr9uMbW347C/F1T4lMePBOai7xdU+CntGjml920ZHMSrQhMJkyGOjflVoaF8X0yGMtzD/kfgG7anIO5t8G3v34Ixzv4XYACzFHcaJd8bjAAAAABJRU5ErkJggg=="></a><a href="addbalance.php"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADEAAAAxCAYAAABznEEcAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAxRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDE0IDc5LjE1Njc5NywgMjAxNC8wOC8yMC0wOTo1MzowMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QzdBMDMxMTRBM0YzMTFFNEIxNkFBMzYyMjIxOEVDQTEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QzdBMDMxMTNBM0YzMTFFNEIxNkFBMzYyMjIxOEVDQTEiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgV2luZG93cyI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSI2MkM5NTc1RDM1OTg5OURFNEU2NTc4NjVGRkRDRkJFNyIgc3RSZWY6ZG9jdW1lbnRJRD0iNjJDOTU3NUQzNTk4OTlERTRFNjU3ODY1RkZEQ0ZCRTciLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7xgoAMAAANfElEQVR42rxaB3Ac5RX+ttztNenUu2Sf5CpZlgvGxAUw4EBiOiTAQDCDCSGFmWQSMoSQSQUSQkjIUBJwwMGQwEACxtgQMJgmYcBWLPfIsqxuydKpXN/d2928LbJ0OhndCZLVvJH2dvffV773vff+E9PhP4bxh8IyECQNcXkINjuLAjYb/ngUQ/EYeNA1ewZYjQW8mQg0N6PznW3Iq6uDMn8twq0HEG56E5xdcLnlcI5D6tdEbZhjWQfj8V08zJT5RoIBCZ3HDsOp9sIlxeGt/RJyF9VBlP3gVECIRACGgUeMQxRYxFg73GEFnKZBYzDpwSOtQyMr42CdWRC5DPhjTshCLpTGZ0pzD2xcP48ZWuZA0M1FBmuB/iIwmgKWfjSy/tDmkdh+20ENFT0+79zmbmHGy36UfTIQdcDGOCAIHiAchK6nkp5SYKaKRD7I42RqgNfgIg/t3d+JYdGD6tCe3NyurRuK1D3fgdpbjjg9zFpyavUx20/9Hu9NVhgZwOrN/WWXPnTcXt5idzixZPlyyIoEm38Iko1BjJs6ElMaUeQoRG/3MbQOhCDlzYa2/6XMWZ0vPlguf7wBDiuWE5VLI7AgCCEGBJH1dkv2jd8N1K7f7xZU1GR7EHTZEFY5eCLTNEKRBsELHIry5+PQR//GJ+/VY7X747sqxRd+Tt7m0wXilIduDEVzIO574aPMW2+efd7NoaIZdgQDI+BHZNh0m1M1QiMjOFGFnQkBGQK6T2RA3PtaybKuO7exin+RsRqDz/9grMjEjbPogbw7vnJi/k3byivLUBYNQZUl44Isx8GoiTow7YOtiQ4h3GcQ+wSiQRzskVG4+4kblgUf3Qzn/0j508EsChxjlj98dMWjty+uKAcX80MlvViCuMaNyzMjEgNHxwxQNdgJQlmeXDTsG0bOzjtuX6y88EcD+/8vA8YbIgMhru65+sIfXddnd4G3Mzh30Ww4nDxFZIzDWEmSMSosMUtoWMSb73ejsvGBby1Wp2nA6P0BkpMk4QmsleoaAuBRm65dPXDv830Sj37FQaytglUZM4csIb0Z6MKQ5XbBgTYpB87dj63zDT78yLQjELdecMlG4KrHgYqVJvmLJP0kI1YxYFOIBuWgK77vq1cPP3p/vpAJzumCzJhMNSp8vs1l3O8S7Dg0yEHbt2XuF/mHt6SkPGMpq01QiIouSmoRX7DBJDEhC9hcD8xfCKy6AejYCvjfN43iUngP3eMLvnqHNDCn5WTop4/PFIYhyWNJwYqhGGSSYIyHv6sTX2i57SlSjkuZQnUjiMgwYMFHsjzuu2RsidZXTO/7rgDOvAPK1e8Bs24DhtOD1tzuB+8f+eTFooiaiayMTLgcLkP4I7veN/qCfr4CC4Y3fzfDrnwBE7L/tIeuWN31wFl3AU1PAD1vA0P7TGNy5htLaCp1Hj3bKNR0klc76liKxH7CbxoQ5QxoeRf0PLBpb+eyi2bnC5BjYbN3Erk4lXYvHLGjRZXhZ+5Nq4jp2C9bQwpXA2t+bxbucC95/lX6fJXhQGaAlG0ZAtw6xFabz/U2Am31pmHpsBVFwysevlA49PR1OzLO/XtuvJM+JtpV7V4EhVLUyu/dTZ84U05kxVwUuXMTScldBNTeQm+bab7b6wNufBa45nkongLzxrYPKC8myaVUDCEnL4u+/E0hHqFTB3W+LLjr111G7e9JYXHovj/TghkpG6Hfp8OhYydw/HVSvsRQeOLjDE8Ul08wyqsx9DWiZSdN2ENAX4eZT640WJDuY9XBGRpX866E8javEqTRQOZQLTbcSKsXp0WnjCX+NmDvv4AnzwfT90lK7tQKlhL1Ejvd9h+gcrFJu2oahpAnZsd23BJnRaJYGg0Gs/ORi6PnGYtMp6rq7UgeTMxrE/gy1A1svQx454fEXgesZpcZ0zVrDpTrKT/O2gAMpudAh/bh2ig7JPTYbWALldYyt1R/1WdqK3RI+M6BVrQk8XM/ebqe6HXHbylStWD+RhHoqk8gPh1iyoVUFOctN9kulUN/KK4UlEcOf1mUBbAlgT2Loai2tNuC8bDSa0N2XYIfDEXbtpt4LyXRq/8R8vqTxFq9Hyc8bsSv7gfmQ1rq9akcHefEPSVg82OtM1KqmlMwBkpXJNVAdO80r6mWpqVW1PZsSl4nq8JkOzV153m1gXnZNKuz1JrMmVY+jB56dc7R68XZibUp0EX1odG8Llo1JWAZXb40eZ1wn9G1psNStnBLlYehOmHjwotTDuHpjPAugOwpnrAFQRl/wU+BmrNMKI1G7NI7oSzckLzOsVdMI9g0qDbcX5GX6S3g7Uq3MG04jeZDyVpj4BuPMMaVC6z4Gf1NEhsEGxuA5qDPSJJe56dW5QAltyfNd7th09q2OXhe1ZhTo+F05mK94M1cm1gHNAX6Xg3PsGY5cRDeSCYiRZMjYI48QxT8DSuiaeQEjF6KUUc69HGCJozpwilu1YnseQkuYgNt4P9CLcZzy6gxJA8HuifdS2JUauB2kAFdVl6p6TvRxnE02bEeZdqJTXMwilZAyfIlft7bRE2gH2jeDbz0deBPZeC2Xg4EOxLvE/KhfY88WFtrVu30a5UacpTH2ShT3JFyJEZhF7GioBtRcu4kGG8y6VKv5AUW5D7aAmycQTNES/Iku/Yps57IaVI7VzzU56gZZKN88b60bNdxke0xjYjpRqxI9kHHDlNxbWzERJk1OL1xS9L98UKi3II60ylpQElS3Ifc5TMjfJAT2otSjYI+iZUvhPa1Jmr29tD5ccSrLkqMhL8ZOPqhGYmJJKCLrCShxniec6WXE+SJEcnRbJ+1HHwQZU1jPfIUEdCvn/F98zbdeyRJM5RCWCumMISIe4es50Y3xfTkPf93yU5VRHCRbiTwdApODXFzG8MHD4Fvy1nZVCvOP2iLHa751KnO6I9IKi76dHsLFgG3EF+OHCfWoeFniOYGkXoNJyVIzfpTw1JCJNrfAk52mJ1wqvlAju8oXvN6JNgJPhTogR9lLxcxZMSnHYKVeM/MAlO4kpKWlC1fA61kJRhb8tuNAcnrS9gUxyTG64Hi9j1iOikzxXpl5Nmchn7G1+omLLFV5Lnj2VdvnLKDZC3whoNUXWmSe/PXwNMXgnnSQwgaMGEhhaBEB5NqAjNOkgzY+yitt92EmpZ6JFqECx5jJQecYQlsdd1SsLOuagugYuunTlfa2LBuwKpwdCvFB9aVZ9p58Alw91Jb0fCLsWW0OD2mnnr8lMSj4Op/DGz/tkmvbFpQ6j8uVL/sYdspIgHwAtoxsyQbLblff2hJz08uSQuXuivn3GTYzho7GwfMDYDe5rH73vkBmBZqvSuuNBmIIfNEyvjjz5oFLseiYDV1aj1qv+IPzVJJqDjWTqd6e0Pk7KSEbvVd+lbFyJbn86Td1xje1qZezOhOy1YZKNPJh+9rIGaiP6qvGLuv9WkSGtlOPJWQlIazCsdRb6o1ikVb54z1vzvDmQE2buYc24UMnFR5zFqyEI1Vd95FBUxOeVG9oHW9a3bZfTSttR6hwZ9asaovWzXjMNUS8rpeiHItybO8n84ANJpY5Kl3cfv3s4trxOWVhaiuqDCEleiqxPDwhHsQ9Va17s659ZtGW5HKjpyuyE7C/0P0hi1nm0Y55oEJWZ3MUItZhT/L5DiO4gOeVZuOl13+zyxtAJG4BlE1hTnZ3QaGmllVEuGkMB8YEVD27o1/KY++c7PRoWop9FKS5VWXhSu9rS6YS9eoLxlqT6+InSb/xBHsf7t626KlZ69Q7cSA6rgosh5GgVuVkGnn4PZkYkGpE/uqf74hzM14w1BmquQehZXDMoS1znv+Q4nbntx+pDt0Ga0KAm/O3XiZUFmlZslhauFZjN/bZ4Inxr7uYhkOkhqA35mFY/9uti1ruHRXtju85DN7croGxI2OObA9/97lM6/ecKTKG0BgUCSCY5JK2Nhzmkb5QRGhTq+iulretfSVpQPSnO0Grpn/swEEUS2Mzl2zNi3MqVt/pFAbRCQagyaoUO1KgkxaYiJhERUOFXNra7BzyeZ1J3KvudvAvTLNMTbdkVf/ro5f+Mrby7f6Clevbz+zkLhY5CFrMliFSZZJOwxK9EAwhAw2hHPPqUPHmXff08htoJa1oP/UF+ift+dHO10G8X3ctetfW/TXy6rPW6cU2XswPDI8ad81KZwS1iXcKca3/QEUOkYwYl/UuCXjl0XHpFW3E7yiRjP4eRgzWvn1bSnnmic+zPxVzl7n6qdzHBJs0jBEUQbDna59nMKIU9ElHlZlGS6pAxkCr548676Hd53xj/xW4cq7qX3tMlZQx0FNS0Fp678HDEfwkAadFz9S7/1N8Y7M628VWXewQOkGK0ehKaltlfOpxjsWiaCgrBQVK5bAPxwPd8w6/55ju7ffk9P3wYpKYf+1GdrASl45vNj4j5rRbUtt/J6mdcT0nHW0Rtw1DX6t9MUW23nb4p7KOIdB5EttsGschTm96sinA1sdYrHgEIVZQnnBDPRQ/9Kr+hoGXFUNYY8TudFQcWmkaaGNiRVCjnltTJAYXWUlVxEnMm5RUl1+cfYZjbHc2S3IKIHHzUP4+AM4acyFUzOaOW0aNPhfAQYAqthZ5jF1cBwAAAAASUVORK5CYII="></a><a href="addbalance.php"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADEAAAAxCAYAAABznEEcAAAFcklEQVRogcXaWYxkVRkH8F91D9AMdCPOxh6TGRkERhbFsAcYhkkMER4mYECQEKMxGEmAgAv66IOJPmjimwbByAOgJCQgOm4RRgMkxCWRRRGCzCCMzgqz0NXNw//cVDVUd9dyb/wnnbqdU32+73++/dymWbRwFZY3LKdRHIfn8YX/tyLDooXr8JQQWdqUoPGmNsYVOB0HsKHI+nUTgsaa2BTH4Hz8F0uwFTfjnCaENUXiUhyO/eJWezGB25sQ1gSJ03EG3uzafxwv4kqJk1pRN4lxrMdBtN+zNoMduAOTdQqtm8R6nCjKvnfvMYmNj+DrdQqtk8RxuFCCubWAvH/gcxL4taBOEpfhMJ1g7oUW3paMdVtdgusisQ6nmRvM82FcrLER19chvA4Sh0gxe0eCtx9UQX4XPjiqAnWQWC/xsMP8btRL7lZ8GF8ZVYFRSZygU5kH3atyq5tx0ShKjEqiO5gHRRXk41I7hsYoJD6KU/UXzPNhHP/E5bhxWEWGFX5oEXxA72CuYuNt6ZtmF9hrBtvFGkMNT8OS2IDjsdPcYK6e9+B/WIW1UhcOYnoeHbbhZHxjGGWGmSdOxKewS+eEW9Ir7RbrHItPSNCvxVFCpF3
                W20X5ivSYHMgF+BNeaZrEJqwoCo/J6VaEVuM8nIsPFYVbmJLWfLJ8tsradHkeE0stl0O6v0kSZ8mssF2K2y454bXSN52DlZKt9hbFJnGkTgZb2kWqVb5zUMca5+J1PNuvUv0WJ5JKvyTE38DRWINTpNjNSCzMdO1budax5bkbh5Tv7ZPD2CNEjymfl0rmWxSDWOJicRFy4ufLAHR4lwLMPZi2WGJS7/miLZluCkfIQe0ocibxeJ0k1kn7fJIE3xox/x6dE+5l1YVIVKjILBG3myz7bpQa8pfFlFvSJ4k1uKYI+bO4U3UAg7jkQmhLnE3IYZG0uyj6tcRz+ImY/SJxgV1CYCES/ViCTqpeISR+L7XooX6U67fYLZOM8XlcLR3oWUKqVwEbBG2x8AqJh024BP+WLndR9EtiKW6QzPFbiYs7JRDXiUUXOuleaEuGWiWn/+3y/JDUm/sk6y2Kft1pNz6AL0s/9BKexk8l1V4iRKuZonKxXu40W9ZXFuUfl3T6MwnyW/EoHsQ9feo3EDYVxW8zN+g+hs2S85/DE9iC38k97G7J+f+RVDyLV6WJrHAx/lDW7m1C+QotKXjfE/PfIJao8FlJibvwDH5TSOzQaU324e6uvzkeP8RbZf2PUnv6xjC90xsyR+yVye4CiY2XpFW4pyhxubhYuyh6GB4Q1/ulxONXy/fPEMsswRfxQtMkdpbPM6WFfkeC+0w58a1y+/2YtCQXFgWvxHfEna4ohK4ta6+WPb6LHw2q0CiF6ia5zdum06lO4e94RPx/Qi4SnhTyq/EtSdNvShqdLftswSeHUWQUElO4RQrfnq79lomrbMEvpEOdkKvLW3Qul6uJcFn5uw3SZgyMUV6yHJAg/bik3QpvieKnymywGj+W039ZLFcNRGOS5b4m2W0ojPqmaJvUgFMkjVY1Yrb8PiNXMmvxt/J7VWCnpQu+H98cRYk6Xne9ID69XCxSuWhLrHJUWTtobhE8ScbQT3v/rDEQ6rgBbOPh8jxh4ZsNZX1p+blT6sdIqOtC+WWpzv1cucyIe30fv6pDeJ1X+5ul5Vhp/mZwWjrTJwx5PdMLdb8p+rnExZT3X6rNSDrdL01ebaibxHYpdEdIC9EdH+PSftyNv9YptIm3p89K87dKxxrTksEeNERbsRia+o+Cf8mbowlxofPwGj4jjWOtaOpl/D4ZcsalVT9SZpBtDclrFGeL4j9oUkiT/6BCZo/9MjPsXPirw+NdHos1+XX7H0cAAAAASUVORK5CYII="></a><a href="addbalance.php"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAABJlBMVEUAAAA+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ew+1Ez///881Eo600k400Y20kQz0kL9//5D1VH0/fVA1U5H1lTn+uln3XJO2Fvx/PLS9dWS55pK11fM9NB94of8/vy68L+b6aJr3nZe22m+8cOs7bJ34YLk+ebf+OGn7K6X6J5j3W75/vr2/ffr++3c+N+077mC44ta22bu+/DC8sei6qmG5Y9w4HpX2mNT2V/Z99vF8smv7rWK5ZOf6qaM5pSHjivbAAAALHRSTlMA5PvxC9Cf7Lk/IRAwA+jgeiYH98eRWjfWpoF0SxfZva6qmYdfUTouFa+YGVmrw5EAAAcESURBVHjavNjpWtpAFAbgSRCUVlvQVrvYvdrtOzMJi7iAssjigi2uSF3a+7+JIvmRhCfLTAh9byCT5JzvnGdYFDPZ9HImNZfUEjqgJ7TkXCqznM7OsP9gYXH++Sx8PHk+v7jApmnlg7aEQEva+xU2JaupBKQkUqssdj8yUPL6DYtT9oUORfrbRywua0lEklxjcVhPIrLkOpvU42eYSHLCcEjpmJD+nUWXfooYaGkWzeJzxOTVQqS/n0BsZiNUwmcdMdI/M0WfELNPTMkzxO4dU/AUU/BUvvw0TIUmOaDeYFoSj6XeH9MzyyRokMVNAUVPZuKqP2Fs7x+XzzgUJRfi6b9S5RcNbRpQ9W7S/OEYEhdk2Yayl4H5iyDCFFuNMwGAH5FlC+pWAxpAh7/SoF8mol4OAD8nS0NA3SPf+ZuAP17O08gGhkSRRg5zsE0cicHz/4gsVQzxG7KPoyzFPKURaIssdTxok6WDKLJREiBHlp5wHucUkSx67Z8IZtySxXQe50Ygiox0B9j4X7LscwDmHo3UTHAhDMM0DMFVOkE9Au0i4AB4gyzV5n6/cVe/rN9V9gcFAUlzbMw6QhXIUsSDDlnyZMvX2pD1hbklEcrs0cjJLjdz17fk6WclJxkG7qm0hnDinkby1coe+asLSJlX/QDALklpC8jQmEMWEoTYISlbkJJmthcIxk2zW2ltkpwdARnfHPcvOvxxURqc3ZKKBqTY61km4OmFykEtT2o2DcWZBB+8Wf5FUXTVynAVfkpB754/vPxT7Z43O0c9GtPiSnmcgp+NC7+Hn+xd2+EvquS2o5bHCfgq+/zk3wXX6OHn5FIsqJThCvzdk6eLDbiJM3cgl1TS8EPgAPJWwJjCTpQv8IoNLWjwZx6QpyqHG7+NUAN4MtqFl+CP31HxamtbmKW/5LRnwI1XyKHOIecrY2weQQbdnMADcUlOGMOvyOE3JC3by3ioJjmdY8wB2coCkj4yxmYhJ1ckhw7cdmsKQWh7xtgMJBktcjg14FRwRvaxAYUbiywk8XtXp+dg46Ue2VoG55DFWBqyun5FwJsnZKv1Lhtd6SOssGXI2vCe+cbAY0OsHTZMDgmvWQayjLIrCTiGBK5b5O2kYyDcB5aCLF51hZ3BUdg+ogBtjlAv2Byk7ebJod8+KFKwUy7RBkmEsweOoi5HiATTIO+QFNU4QiyxBOQdk6o+QuhMh7xdUnVjIgSDgtwFedks168q/fs/LY/lYTvGA9gj2Vb716vdNjUNBHEA35TYJ9sOoCAPiugb0PnfJekzhZYKLQqoVEQZFBG//5dwJjZDjnbY2zb1967TF7lpby97u1v79cHzPYS03x/ZpqdgUAqTb4KjXquujeS0vq9MX8AQbULsmD+vr3FfcK0MA3YTOhDwVdxXfo3qjA3DRxAI9s1SBJu3qEqdO4iyENBG+l8rY1TwXbSADKUh8aPC5Z7+kWgBKzQPicY7FXOJUeWmiqux3YNlSHjHXIy1lKHJJiQ5SOiPD14Rw1aGYY9NyRYg0nj4ioiW8G1E5EJED4yTQDMpQ6XMpuVUgoTeM35gH3H+zq4y3Wr2YkJLEGmruHr88T9v1D2VBsBezQrTbIKLu9dQ51yN2NH85dS8nvPKJ6NXRO1Xbwfv1IhLDcb2sEAh4F2aV0S/3Pp6fjw+LQ9gU6CgTYh8MF52/fc1NV6lHYCzFhWpxDkB71sHvEJUppPoKQtnXdhwo0KlPe0fKNZJ29ewkDVKtTyNaqPfVIzPJ30fdvI0BCud8+bumWIMuh0NSw5F1i1fhLxeoGEtTZEXKVjoKl5Xw15spmZDegCYau9PBXX6yCbdyU8ef5XDnZbvdQQ12khO2rb7NH4BYWYaNIch0IAtR9y4vIjHWm0v2pO/PQBeW1qkxZakdWtmW8eHF526rtZUaC+If9n2YKdUFDev62Fx7ONVYzhANYjXraPlNMuwUyBx9zo4Proq352x+iCK/fBjdEJ2YCVL97kpCF1FpeFwOcKhkjyNeAuhwGhe9KOKhIaFeX6Mjudfx1Pv8tlwEwTgzS3yYzw8fRPvlnv7YcVmv6ch+ANMa5DpRrlf+Omwct7rVLUGb5XGK2Yg0ojyj39RGvgaVjbIwEQCm6F/bh5AZoEZ57Pm/VG7p31I5ZIbqK62PE9DaIke9BIzluWHWmfKIZaDGUq5xHoxh2TJR6szkJA/n1fCTKRsn0/uI8yA45K14gyiMUsiq0jYEgk9R6JyJJZP8EjaWKBJpJGQVZrQQjLRn6eJLc5javOLNI18FlPJ5mlaW1NsxlKBElAsOJiIs1WkhOTeQGwzR0ly0w4EnPRjSlw+K9x5yXMLayUwSmsFl2Zpe/n10wzGyjx9vbxN/8ez9VcrmbknKQBIPZnLrKyuP6OJ/AVews8ekRmWFAAAAABJRU5ErkJggg=="></a><a href="addbalance.php"><img src="../static/media/ltclogo2.1bacf135.png"></a></div>
            </div>
            <br>
            </div>
        </div>
        <br><br>
    </div>
</div>
<div></div>
<div class="overlay"></div>
</div>
</div>
<script src="../js/script3.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="../js/script4.js"></script><script src="../js/jquery.floatThead.js"></script><script src="../js/mainJS.js"></script><script src="https://www.gstatic.com/charts/loader.js" async=""></script>
   </body>
</html><script>
function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}
    var todayDate = new Date();
    var yesterday = new Date();
    var dayBeforeYesterday = new Date();

yesterday.setDate(yesterday.getDate() - 1);
dayBeforeYesterday.setDate(yesterday.getDate() - 1);
$("#todayDate").html(formatDate(todayDate));
$("#previousDate").html(formatDate(yesterday));
$("#dayBeforeYesterdayDate").html(formatDate(dayBeforeYesterday));
</script>
