<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#000000">
    <meta name="keywords" content="Buy Spamming Tools | Fresh SMTP Shop | Buy Inbox Mailer | Buy Spam Tools | Buy Paid Account | Buy Fresh RDP | Rdp Shop | Fresh Spam Shop | buy Fresh Smtp | Fresh Shell | Fresh Smtp | Fresh Office365 smtp | Paid Date Account| Spam Tools | SMTP | SHELL | MAILER | cPanel | FTP | Combo List | Fresh RDP | Fresh Tools | Valid shod | spammer shop | Fresh Cpanel , Fresh Shell, Hacking RDP , Hacking shop , Buy Spamming Tools | Spammer Tools | Inbox Mailer | Buy Tools Spam | Spamming Tools | Rdp Shop | Site To Buy Spamming Tools | Buy Spamm Equipments | Buy Carding Accounts |FreshTools,Spam Tools,SMTP,SHELL,MAILER,cPanel,FTP,Combo List,Fresh RDP,Fresh Tools,Valid shod,spammer shop,Fresh Cpanel">
    <meta name="description" content="Buy Spamming Tools | Fresh SMTP Shop | Buy Inbox Mailer | Buy Spam Tools | Buy Paid Account | Buy Fresh RDP | Rdp Shop | Fresh Spam Shop | buy Fresh Smtp | Fresh Shell | Fresh Smtp | Fresh Office365 smtp | Paid Date Account| Spam Tools | SMTP | SHELL | MAILER | cPanel | FTP | Combo List | Fresh RDP | Fresh Tools | Valid shod | spammer shop | Fresh Cpanel , Fresh Shell, Hacking RDP , Hacking shop , Buy Spamming Tools | Spammer Tools | Inbox Mailer | Buy Tools Spam | Spamming Tools | Rdp Shop | Site To Buy Spamming Tools | Buy Spamm Equipments | Buy Carding Accounts |FreshTools,Spam Tools,SMTP,SHELL,MAILER,cPanel,FTP,Combo List,Fresh RDP,Fresh Tools,Valid shod,spammer shop,Fresh Cpanel">
    <link rel="apple-touch-icon" href="../logo192.png">
    <link rel="manifest" href="../manifest.json">
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Lato">
    <link href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" rel="stylesheet">
    <title>FreshTools | Spam Tools | SMTP | SHELL | MAILER | cPanel | FTP | Combo List | Fresh RDP | Fresh Tools | Valid shod | spammer shop | Fresh Cpanel , Fresh Shell, Hacking RDP , Hacking shop , Buy Spamming Tools | Spammer Tools | Inbox Mailer | Buy Tools Spam | Spamming Tools | Rdp Shop | Site To Buy Spamming Tools | Buy Spamm Equipments | Buy Carding Accounts |</title>
    <link href="../css/styles.css" rel="stylesheet">
    <script charset="utf-8" src="../js/script1.js"></script><script charset="utf-8" src="../js/script2.js"></script><script charset="utf-8" src="../js/24.5bf4e7b1.chunk.js"></script><script charset="utf-8" src="../js/27.7e940a6d.chunk.js"></script><script charset="utf-8" src="../js/25.23ed498c.chunk.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/loader.js"></script>
    <link id="load-css-0" rel="stylesheet" type="text/css" href="https://www.gstatic.com/charts/49/css/core/tooltip.css">
    <link id="load-css-1" rel="stylesheet" type="text/css" href="https://www.gstatic.com/charts/49/css/util/util.css">
    <link id="load-css-2" rel="stylesheet" type="text/css" href="https://www.gstatic.com/charts/49/css/controls/controls.css">
    <script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_default_module.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_graphics_module.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_ui_module.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_corechart_module.js"></script><script type="text/javascript" charset="UTF-8" src="https://www.gstatic.com/charts/49/js/jsapi_compiled_controls_module.js"></script>
</head>
<body style="height:100%">
<div style="height:100%" id="root">
<div class="userPanelBackground" style="">
<div class="header  card">
    <div class="p-0 m-0 card-body">
        <div class="p-0 m-0 header-container row">
            <div class="col-lg-7">
            <ul class="header-nav">
                <a href="index.php" class="navbar-brand">FreshTools</a>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="hostDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-server"></i><span>Hosts</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="hostDropDown">
                        <li><a href="rdp.php"><i class="fa fa-desktop fa-fw"></i><span>Rdps</span><span class="badge badge-light">781</span></a></li>
                        <li><a href="cpanel.php"><i class="fas fa-tools fa-fw"></i><span>Cpanel</span><span class="badge badge-light">1009</span></a></li>
                        <li><a href="ssh.php"><i class="fa fa-terminal fa-fw"></i><span>SSH</span><span class="badge badge-light">555</span></a></li>
                        <li><a href="shell.php"><i class="fa fa-file-code-o fa-fw"></i><span>Shells</span><span class="badge badge-light">27435</span></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="sendDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-mail-bulk"></i><span>Send</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="sendDropDown">
                        <li><a href="webmail.php"><i class="flaticon-inbox"></i><span>Webmail</span><span class="badge badge-light">19924</span></a></li>
                        <li><a href="phpmailers.php"><i class="fas fa-leaf fa-fw"></i><span>Php Mailers</span><span class="badge badge-light">26582</span></a></li>
                        <li><a href="smtp.php"><i class="fas fa-envelope fa-fwl"></i><span>Smtps</span><span class="badge badge-light">35941</span></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="leadDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-address-book"></i><span>Leads</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="leadDropDown">
                        <li><a href="leads.php"><i class="fas fa-at fa-fw"></i><span>Leads</span><span class="badge badge-light">6738</span></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="leadDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-users"></i><span>Accounts</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="leadDropDown">
                        <li><a href="accounts.php"><i class="fa fa-users"></i><span>Account</span><span class="badge badge-light" style="margin-top: 4px;">5962</span></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="leadDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user-secret"></i><span>Vip</span></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="leadDropDown">
                        <li><a href="vip.php"><i class="fa fa-user-secret"></i><span>Other</span><span class="badge badge-light" style="margin-top: 4px;">30</span></a></li>
                        <li><a href="bankaccount.php"><i class="fa fa-university"></i><span>Bank Account</span><span class="badge badge-light" style="margin-top: 4px;">5</span></a></li>
                        <li><a href="fullz.php"><i class="fa fa-university"></i><span>CC / Fullz</span><span class="badge badge-light" style="margin-top: 4px;">0</span></a></li>
                    </ul>
                </li>
            </ul>
            </div>
            <div class="col-lg-5">
            <ul dir="ltr" class="header-nav right-nav">
                <li class="dropdown">
                    <a class="dropdown-toggle" href="#" id="AccountDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>My Account</span><i class="fas fa-user"></i></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="AccountDropDown">
                        <li><a href="profile.php"><span>Setting</span><i class="fas fa-user-cog fa-fw"></i></a></li>
                        <li><a href="orders.php"><span>My Orders</span><i class="fas fa-shopping-cart fa-fw"></i></a></li>
                        <li><a href="addbalance.php"><span>Add Balance</span><i class="fas fa-dollar-sign fa-fw"></i></a></li>
                        <li><a href="notification.php"><span>Inbox</span><i class="fas fa-inbox fa-fw"></i></a></li>
                        <li><a href="logout.php"><span>Logout</span><i class="fas fa-sign-out-alt fa-fw"></i></a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="TicketDropDown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Ticket</span><i class="fas fa-inbox"></i></a>
                    <ul class="dropdown-menu header-nav drop-nav" aria-labelledby="TicketDropDown">
                        <li><a href="tickets.php"><span>Ticket</span><i class="fas fa-comments fa-fw"></i><span class="badge badge-light">0</span></a></li>
                        <li><a href="reports.php"><span>reports</span><i class="fas fa-flag fa-fw"></i><span class="badge badge-light">0</span></a></li>
                    </ul>
                </li>
                <li><a class="add-balance" href="addbalance.php"><i class="fas fa-plus-circle"></i><span>0.00</span></a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" href="" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bell" style="font-size: 16px; margin-right: 5px; color: rgb(255, 255, 255);"></i><span class="notification-badge badge badge-danger" style="margin-top: -5px;">0</span></a>
                    <ul class="dropdown-menu header-nav drop-nav notificationList" aria-labelledby="notification">
                        <li>No notification</li>
                    </ul>
                </li>
            </ul>
            </div>
        </div>
    </div>
</div><div>
   <div class="listContainer">
      <div class="card">
         <div class="card-body">
            <p>You need to Pay $100 to access this Vip section</p>
            <button type="button" class="btn btn-info btn btn-secondary paynow">Pay Now!</button>
         </div>
      </div>
   </div>
</div>
<div></div>
<div class="overlay"></div>
</div>
</div>
<script src="../js/script3.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="../js/script4.js"></script><script src="../js/jquery.floatThead.js"></script><script src="../js/mainJS.js"></script><script src="https://www.gstatic.com/charts/loader.js" async=""></script>
   </body>
</html>