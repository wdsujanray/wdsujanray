(this["webpackJsonpspamx-new-ui"] = this["webpackJsonpspamx-new-ui"] || []).push([
    [5], {
        26: function(e, n, t) {
            e.exports = t(39)
        },
        31: function(e, n, t) {},
        33: function(e, n, t) {},
        39: function(e, n, t) {
            "use strict";
            t.r(n);
            var a = t(0),
                r = t.n(a),
                o = t(19),
                l = t.n(o),
                c = (t(31), t(9)),
                i = t.n(c),
                u = t(20),
                s = t(14),
                m = t(15),
                g = t(17),
                d = t(16),
                h = t(8),
                p = t(1);
            t(33), t(10);
            window.$ = window.jQuery = t(10), window.Bootstrap = t(34);
            var f = function() {
                    return r.a.createElement("div", {
                        className: "animated fadeIn pt-3 text-center"
                    }, "Loading...")
                },
                k = r.a.lazy((function() {
                    return Promise.all([t.e(1), t.e(24)]).then(t.bind(null, 201))
                })),
                E = r.a.lazy((function() {
                    return Promise.all([t.e(1), t.e(23)]).then(t.bind(null, 171))
                })),
                b = r.a.lazy((function() {
                    return Promise.all([t.e(1), t.e(2), t.e(53)]).then(t.bind(null, 172))
                })),
                v = r.a.lazy((function() {
                    return Promise.all([t.e(1), t.e(2), t.e(52)]).then(t.bind(null, 173))
                })),
                w = r.a.lazy((function() {
                    return Promise.all([t.e(1), t.e(2), t.e(51)]).then(t.bind(null, 174))
                })),
                y = function(e) {
                    Object(g.a)(t, e);
                    var n = Object(d.a)(t);

                    function t(e) {
                        var a;
                        Object(s.a)(this, t), (a = n.call(this, e)).state = {
                            login: !1
                        };
                        var r = (new Date).getTime() - 36e5,
                            o = localStorage.getItem("currentDate");
                        return null !== o && "null" !== o ? parseInt(o) < r && (localStorage.removeItem("apiToken"), localStorage.removeItem("sellerApiToken")) : localStorage.removeItem("apiToken"), a.CheckUserLogin(), a
                    }
                    return Object(m.a)(t, [{
                        key: "CheckUserLogin",
                        value: function() {
                            var e = Object(u.a)(i.a.mark((function e() {
                                var n;
                                return i.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, localStorage.getItem("apiToken");
                                        case 3:
                                            null !== (n = e.sent) && "null" !== n && this.setState({
                                                login: !0
                                            }), e.next = 10;
                                            break;
                                        case 7:
                                            e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);
                                        case 10:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this, [
                                    [0, 7]
                                ])
                            })));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "loginBlock",
                        value: function() {
                            return r.a.createElement(h.a, null, r.a.createElement(r.a.Suspense, {
                                fallback: f()
                            }, r.a.createElement(p.d, null, r.a.createElement(p.b, {
                                path: "/",
                                name: "Home",
                                render: function(e) {
                                    return r.a.createElement(k, e)
                                }
                            }))))
                        }
                    }, {
                        key: "NotloginBlock",
                        value: function() {
                            return r.a.createElement(h.a, null, r.a.createElement(r.a.Suspense, {
                                fallback: f()
                            }, r.a.createElement(p.d, null, r.a.createElement(p.b, {
                                exact: !0,
                                path: "/reset/password",
                                name: "Login Page",
                                render: function(e) {
                                    return r.a.createElement(v, e)
                                }
                            }), r.a.createElement(p.b, {
                                exact: !0,
                                path: "/reset/code/:token",
                                name: "Login Page",
                                render: function(e) {
                                    return r.a.createElement(w, e)
                                }
                            }), r.a.createElement(p.b, {
                                exact: !0,
                                path: "/register/:code",
                                name: "Login Page",
                                render: function(e) {
                                    return r.a.createElement(b, e)
                                }
                            }), r.a.createElement(p.b, {
                                exact: !0,
                                path: "/register",
                                name: "Login Page",
                                render: function(e) {
                                    return r.a.createElement(b, e)
                                }
                            }), r.a.createElement(p.b, {
                                path: "/",
                                name: "Login Page",
                                render: function(e) {
                                    return r.a.createElement(E, e)
                                }
                            }), r.a.createElement(p.b, {
                                exact: !0,
                                path: "/login",
                                name: "Login Page",
                                render: function(e) {
                                    return r.a.createElement(E, e)
                                }
                            }))))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this.state.login ? this.loginBlock() : this.NotloginBlock()
                        }
                    }]), t
                }(a.Component);
            Boolean("localhost" === window.location.hostname || "[::1]" === window.location.hostname || window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/));
            l.a.render(r.a.createElement(y, null), document.getElementById("root")), "serviceWorker" in navigator && navigator.serviceWorker.ready.then((function(e) {
                e.unregister()
            }))
        }
    },
    [
        [26, 6, 7]
    ]
]);
//# sourceMappingURL=main.d0210b9a.chunk.js.map