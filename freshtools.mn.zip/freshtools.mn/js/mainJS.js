$(document).ready(function() {




    $(window).scroll(function() {
        let $header = $('.header');
        let headerBottom = $header.position().top + $header.outerHeight(true);
        $(".listContainer .show-items").floatThead();

        if ($(this).scrollTop() > headerBottom) {
            $(".floatThead-container").css({
                top: headerBottom + 'px',
                backgroundColor: "#FFF"
            });

        }
    });





    // $(window).scroll(function () {
    //
    //     let $header =  $('.header');
    //     let headerBottom =  $header.position().top + $header.outerHeight(true);
    //
    //
    //
    //     let $table = $('.tools-list');
    //
    //     let top =  $(window).scrollTop();
    //
    //
    //
    //     if(top >= $table.offset().top){
    //
    //         $table.addClass('sticky-header');
    //         $('.tools-list thead ').css('top',headerBottom+'px');
    //
    //
    //     }else{
    //
    //         $table.removeClass('sticky-header');
    //
    //     }
    //
    //
    //
    //
    // });

    let toogle_sm = false;
    let toogle_sidebar = false;

    $("#mobile-category-bar").click(function() {

        $('.mobile-sidebar').addClass('sidebar-show');
        $('.overlay').show();
        toogle_sidebar = true;

    });


    $(".overlay").click(function() {

        $('.mobile-sidebar').removeClass('sidebar-show');
        $('.overlay').hide();

    });




});