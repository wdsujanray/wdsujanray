(this["webpackJsonpspamx-new-ui"] = this["webpackJsonpspamx-new-ui"] || []).push([
    [24], {
        165: function(e, a, t) {
            "use strict";
            var n = t(2),
                l = t(6),
                r = t(0),
                o = t.n(r),
                c = t(7),
                s = t.n(c),
                i = t(40),
                u = t.n(i),
                m = t(41),
                p = {
                    tag: m.p,
                    inverse: s.a.bool,
                    color: s.a.string,
                    body: s.a.bool,
                    outline: s.a.bool,
                    className: s.a.string,
                    cssModule: s.a.object,
                    innerRef: s.a.oneOfType([s.a.object, s.a.string, s.a.func])
                },
                d = function(e) {
                    var a = e.className,
                        t = e.cssModule,
                        r = e.color,
                        c = e.body,
                        s = e.inverse,
                        i = e.outline,
                        p = e.tag,
                        d = e.innerRef,
                        f = Object(l.a)(e, ["className", "cssModule", "color", "body", "inverse", "outline", "tag", "innerRef"]),
                        h = Object(m.l)(u()(a, "card", !!s && "text-white", !!c && "card-body", !!r && (i ? "border" : "bg") + "-" + r), t);
                    return o.a.createElement(p, Object(n.a)({}, f, {
                        className: h,
                        ref: d
                    }))
                };
            d.propTypes = p, d.defaultProps = {
                tag: "div"
            }, a.a = d
        },
        166: function(e, a, t) {
            "use strict";
            var n = t(2),
                l = t(6),
                r = t(0),
                o = t.n(r),
                c = t(7),
                s = t.n(c),
                i = t(40),
                u = t.n(i),
                m = t(41),
                p = {
                    tag: m.p,
                    className: s.a.string,
                    cssModule: s.a.object,
                    innerRef: s.a.oneOfType([s.a.object, s.a.string, s.a.func])
                },
                d = function(e) {
                    var a = e.className,
                        t = e.cssModule,
                        r = e.innerRef,
                        c = e.tag,
                        s = Object(l.a)(e, ["className", "cssModule", "innerRef", "tag"]),
                        i = Object(m.l)(u()(a, "card-body"), t);
                    return o.a.createElement(c, Object(n.a)({}, s, {
                        className: i,
                        ref: r
                    }))
                };
            d.propTypes = p, d.defaultProps = {
                tag: "div"
            }, a.a = d
        },
        167: function(e, a, t) {
            "use strict";
            var n = t(2),
                l = t(6),
                r = t(0),
                o = t.n(r),
                c = t(7),
                s = t.n(c),
                i = t(40),
                u = t.n(i),
                m = t(41),
                p = s.a.oneOfType([s.a.number, s.a.string]),
                d = {
                    tag: m.p,
                    noGutters: s.a.bool,
                    className: s.a.string,
                    cssModule: s.a.object,
                    form: s.a.bool,
                    xs: p,
                    sm: p,
                    md: p,
                    lg: p,
                    xl: p
                },
                f = {
                    tag: "div",
                    widths: ["xs", "sm", "md", "lg", "xl"]
                },
                h = function(e) {
                    var a = e.className,
                        t = e.cssModule,
                        r = e.noGutters,
                        c = e.tag,
                        s = e.form,
                        i = e.widths,
                        p = Object(l.a)(e, ["className", "cssModule", "noGutters", "tag", "form", "widths"]),
                        d = [];
                    i.forEach((function(a, t) {
                        var n = e[a];
                        if (delete p[a], n) {
                            var l = !t;
                            d.push(l ? "row-cols-" + n : "row-cols-" + a + "-" + n)
                        }
                    }));
                    var f = Object(m.l)(u()(a, r ? "no-gutters" : null, s ? "form-row" : "row", d), t);
                    return o.a.createElement(c, Object(n.a)({}, p, {
                        className: f
                    }))
                };
            h.propTypes = d, h.defaultProps = f, a.a = h
        },
        168: function(e, a, t) {
            "use strict";
            var n = t(2),
                l = t(6),
                r = t(0),
                o = t.n(r),
                c = t(7),
                s = t.n(c),
                i = t(40),
                u = t.n(i),
                m = t(41),
                p = s.a.oneOfType([s.a.number, s.a.string]),
                d = s.a.oneOfType([s.a.bool, s.a.number, s.a.string, s.a.shape({
                    size: s.a.oneOfType([s.a.bool, s.a.number, s.a.string]),
                    order: p,
                    offset: p
                })]),
                f = {
                    tag: m.p,
                    xs: d,
                    sm: d,
                    md: d,
                    lg: d,
                    xl: d,
                    className: s.a.string,
                    cssModule: s.a.object,
                    widths: s.a.array
                },
                h = {
                    tag: "div",
                    widths: ["xs", "sm", "md", "lg", "xl"]
                },
                E = function(e, a, t) {
                    return !0 === t || "" === t ? e ? "col" : "col-" + a : "auto" === t ? e ? "col-auto" : "col-" + a + "-auto" : e ? "col-" + t : "col-" + a + "-" + t
                },
                g = function(e) {
                    var a = e.className,
                        t = e.cssModule,
                        r = e.widths,
                        c = e.tag,
                        s = Object(l.a)(e, ["className", "cssModule", "widths", "tag"]),
                        i = [];
                    r.forEach((function(a, n) {
                        var l = e[a];
                        if (delete s[a], l || "" === l) {
                            var r = !n;
                            if (Object(m.j)(l)) {
                                var o, c = r ? "-" : "-" + a + "-",
                                    p = E(r, a, l.size);
                                i.push(Object(m.l)(u()(((o = {})[p] = l.size || "" === l.size, o["order" + c + l.order] = l.order || 0 === l.order, o["offset" + c + l.offset] = l.offset || 0 === l.offset, o)), t))
                            } else {
                                var d = E(r, a, l);
                                i.push(d)
                            }
                        }
                    })), i.length || i.push("col");
                    var p = Object(m.l)(u()(a, i), t);
                    return o.a.createElement(c, Object(n.a)({}, s, {
                        className: p
                    }))
                };
            g.propTypes = f, g.defaultProps = h, a.a = g
        },
        169: function(e, a, t) {
            "use strict";
            var n = t(2),
                l = t(6),
                r = t(0),
                o = t.n(r),
                c = t(7),
                s = t.n(c),
                i = t(40),
                u = t.n(i),
                m = t(41),
                p = {
                    color: s.a.string,
                    pill: s.a.bool,
                    tag: m.p,
                    innerRef: s.a.oneOfType([s.a.object, s.a.func, s.a.string]),
                    children: s.a.node,
                    className: s.a.string,
                    cssModule: s.a.object
                },
                d = function(e) {
                    var a = e.className,
                        t = e.cssModule,
                        r = e.color,
                        c = e.innerRef,
                        s = e.pill,
                        i = e.tag,
                        p = Object(l.a)(e, ["className", "cssModule", "color", "innerRef", "pill", "tag"]),
                        d = Object(m.l)(u()(a, "badge", "badge-" + r, !!s && "badge-pill"), t);
                    return p.href && "span" === i && (i = "a"), o.a.createElement(i, Object(n.a)({}, p, {
                        className: d,
                        ref: c
                    }))
                };
            d.propTypes = p, d.defaultProps = {
                color: "secondary",
                pill: !1,
                tag: "span"
            }, a.a = d
        },
        201: function(e, a, t) {
            "use strict";
            t.r(a);
            var n = t(14),
                l = t(15),
                r = t(18),
                o = t(17),
                c = t(16),
                s = t(0),
                i = t.n(s),
                u = t(1),
                m = t(8),
                p = t(165),
                d = t(166),
                f = t(167),
                h = t(168),
                E = t(2),
                g = t(6),
                b = t(7),
                w = t.n(b),
                v = t(40),
                N = t.n(v),
                y = t(41),
                O = {
                    tag: y.p,
                    className: w.a.string,
                    cssModule: w.a.object
                },
                k = function(e) {
                    var a = e.className,
                        t = e.cssModule,
                        n = e.tag,
                        l = Object(g.a)(e, ["className", "cssModule", "tag"]),
                        r = Object(y.l)(N()(a, "navbar-brand"), t);
                    return i.a.createElement(n, Object(E.a)({}, l, {
                        className: r
                    }))
                };
            k.propTypes = O, k.defaultProps = {
                tag: "a"
            };
            var j, x = k,
                C = t(169),
                D = t(170),
                S = t(49),
                T = t(61),
                z = "",
                P = function(e) {
                    Object(o.a)(t, e);
                    var a = Object(c.a)(t);

                    function t(e) {
                        var l;
                        return Object(n.a)(this, t), l = a.call(this, e), z = Object(r.a)(l), l.toggle = l.toggle.bind(Object(r.a)(l)), l.state = {
                            categoryList: [],
                            productCount: [],
                            isOpen: !1,
                            cat_id: "",
                            basketCount: "",
                            width: 0,
                            showSuggest: !1,
                            searchSuggest: [],
                            search: "",
                            seller: "",
                            notificationAlert: 0,
                            notificationList: []
                        }, l
                    }
                    return Object(l.a)(t, [{
                        key: "toggle",
                        value: function() {
                            this.setState({
                                isOpen: !this.state.isOpen
                            })
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            console.log("arminarmin", localStorage.getItem("sellerApiToken")), this.setState({
                                seller: localStorage.getItem("sellerInventory")
                            });
                            var e = {
                                api_token: localStorage.getItem("apiToken"),
                                getcounter: 1
                            };
                            setTimeout((function() {
                                S.a.NetworkingRequest("POST", "webservice/v1/dashboard", e).then((function(e) {
                                    "success" === e.status ? (z.setState({
                                        information: e.response,
                                        notificationAlert: e.response.totalNotification,
                                        notificationList: e.response.notification,
                                        productCount: e.response.ProductCount
                                    }), localStorage.setItem("productCount", JSON.stringify(e.response.ProductCount)), localStorage.setItem("inventory", e.response.inventory)) : z.setState({
                                        loading: !1
                                    })
                                }))
                            }), 600), z.updateWindowDimensions(), window.addEventListener("resize", z.updateWindowDimensions)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            window.removeEventListener("resize", z.updateWindowDimensions)
                        }
                    }, {
                        key: "updateWindowDimensions",
                        value: function() {
                            z.setState({
                                width: window.innerWidth,
                                height: window.innerHeight
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return i.a.createElement(i.a.Fragment, null, i.a.createElement(p.a, {
                                className: "header "
                            }, i.a.createElement(d.a, {
                                className: "p-0 m-0"
                            }, i.a.createElement(f.a, {
                                className: "p-0 m-0 header-container"
                            }, i.a.createElement(h.a, {
                                lg: "7"
                            }, i.a.createElement("ul", {
                                className: "header-nav"
                            }, i.a.createElement(x, {
                                href: "/"
                            }, "FreshTools"), i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                className: "dropdown-toggle",
                                href: "",
                                id: "hostDropDown",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("i", {
                                className: "fa fa-server"
                            }), i.a.createElement("span", null, "Hosts")), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav",
                                "aria-labelledby": "hostDropDown"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/rdp"
                            }, i.a.createElement("i", {
                                className: "fa fa-desktop fa-fw"
                            }), i.a.createElement("span", null, "Rdps"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.rdps) : null)), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/cpanelList"
                            }, i.a.createElement("i", {
                                className: "fas fa-tools fa-fw"
                            }), i.a.createElement("span", null, "Cpanel"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.cpanel) : null)), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/ssh"
                            }, i.a.createElement("i", {
                                className: "fa fa-terminal fa-fw"
                            }), i.a.createElement("span", null, "SSH"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.vps) : null)), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/shell"
                            }, i.a.createElement("i", {
                                className: "fa fa-file-code-o fa-fw"
                            }), i.a.createElement("span", null, "Shells"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.shells) : null)))), i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                className: "dropdown-toggle",
                                href: "",
                                id: "sendDropDown",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("i", {
                                className: "fas fa-mail-bulk"
                            }), i.a.createElement("span", null, "Send")), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav",
                                "aria-labelledby": "sendDropDown"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/webMail"
                            }, i.a.createElement("i", {
                                className: "flaticon-inbox"
                            }), i.a.createElement("span", null, "Webmail"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.webmail) : null)), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/phpMailers"
                            }, i.a.createElement("i", {
                                className: "fas fa-leaf fa-fw"
                            }), i.a.createElement("span", null, "Php Mailers"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.phpmailers) : null)), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/smtp"
                            }, i.a.createElement("i", {
                                className: "fas fa-envelope fa-fwl"
                            }), i.a.createElement("span", null, "Smtps"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.smtp) : null)))), i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                className: "dropdown-toggle",
                                href: "",
                                id: "leadDropDown",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("i", {
                                className: "fas fa-address-book"
                            }), i.a.createElement("span", null, "Leads")), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav",
                                "aria-labelledby": "leadDropDown"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/leads"
                            }, i.a.createElement("i", {
                                className: "fas fa-at fa-fw"
                            }), i.a.createElement("span", null, "Leads"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.leads) : null)))), i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                className: "dropdown-toggle",
                                href: "",
                                id: "leadDropDown",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("i", {
                                className: "fa fa-users"
                            }), i.a.createElement("span", null, "Accounts")), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav",
                                "aria-labelledby": "leadDropDown"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/accounts"
                            }, i.a.createElement("i", {
                                className: "fa fa-users"
                            }), i.a.createElement("span", null, "Account"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light",
                                style: {
                                    marginTop: 4
                                }
                            }, this.state.productCount.account) : null)))), i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                className: "dropdown-toggle",
                                href: "",
                                id: "leadDropDown",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("i", {
                                className: "fa fa-user-secret"
                            }), i.a.createElement("span", null, "Vip")), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav",
                                "aria-labelledby": "leadDropDown"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/vip"
                            }, i.a.createElement("i", {
                                className: "fa fa-user-secret"
                            }), i.a.createElement("span", null, "Other"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light",
                                style: {
                                    marginTop: 4
                                }
                            }, this.state.productCount.vip) : null)), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/bankaccount"
                            }, i.a.createElement("i", {
                                className: "fa fa-university"
                            }), i.a.createElement("span", null, "Bank Account"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light",
                                style: {
                                    marginTop: 4
                                }
                            }, this.state.productCount.bank) : null)), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/fullz"
                            }, i.a.createElement("i", {
                                className: "fa fa-university"
                            }), i.a.createElement("span", null, "CC / Fullz"), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light",
                                style: {
                                    marginTop: 4
                                }
                            }, this.state.productCount.fullz) : null)))))), i.a.createElement(h.a, {
                                lg: "5"
                            }, i.a.createElement("ul", {
                                dir: "ltr",
                                className: "header-nav right-nav"
                            }, i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                className: "dropdown-toggle",
                                href: "#",
                                id: "AccountDropDown",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("span", null, "My Account"), i.a.createElement("i", {
                                className: "fas fa-user"
                            })), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav",
                                "aria-labelledby": "AccountDropDown"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/profile"
                            }, i.a.createElement("span", null, "Setting"), i.a.createElement("i", {
                                className: "fas fa-user-cog fa-fw"
                            }))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/orders"
                            }, i.a.createElement("span", null, "My Orders"), i.a.createElement("i", {
                                className: "fas fa-shopping-cart fa-fw"
                            }))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/AddBalance"
                            }, i.a.createElement("span", null, "Add Balance"), i.a.createElement("i", {
                                className: "fas fa-dollar-sign fa-fw"
                            }))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/notification"
                            }, i.a.createElement("span", null, "Inbox"), i.a.createElement("i", {
                                className: "fas fa-inbox fa-fw"
                            }))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/",
                                onClick: function() {
                                    localStorage.removeItem("apiToken"), localStorage.removeItem("sellerInventory"), localStorage.removeItem("sellerApiToken")
                                }
                            }, i.a.createElement("span", null, "Logout"), i.a.createElement("i", {
                                className: "fas fa-sign-out-alt fa-fw"
                            }))))), i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                className: "dropdown-toggle",
                                href: "",
                                id: "TicketDropDown",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("span", null, "Ticket"), i.a.createElement("i", {
                                className: "fas fa-inbox"
                            })), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav",
                                "aria-labelledby": "TicketDropDown"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/tickets"
                            }, i.a.createElement("span", null, "Ticket"), i.a.createElement("i", {
                                className: "fas fa-comments fa-fw"
                            }), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.ticket) : null)), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/reports"
                            }, i.a.createElement("span", null, "reports"), i.a.createElement("i", {
                                className: "fas fa-flag fa-fw"
                            }), null !== this.state.productCount ? i.a.createElement(C.a, {
                                color: "light"
                            }, this.state.productCount.report) : null)))), i.a.createElement("li", null, i.a.createElement("a", {
                                className: "add-balance",
                                href: "/AddBalance"
                            }, i.a.createElement("i", {
                                className: "fas fa-plus-circle"
                            }), i.a.createElement("span", null, localStorage.getItem("inventory")))), "" !== this.state.seller && null !== this.state.seller ? i.a.createElement("li", null, i.a.createElement("a", {
                                href: T.a.base_url + "/sellerPanel/"
                            }, i.a.createElement(D.a, {
                                className: "btn btn-info"
                            }, i.a.createElement("i", {
                                className: "fa fa-cloud"
                            }), i.a.createElement("span", null, this.state.seller)))) : null, i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                onMouseOver: function() {
                                    return e.readNotif()
                                },
                                className: "dropdown-toggle",
                                href: "",
                                id: "notification",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("i", {
                                style: {
                                    fontSize: 16,
                                    marginRight: 5,
                                    color: "#fff"
                                },
                                className: "fa fa-bell"
                            }), i.a.createElement(C.a, {
                                style: {
                                    marginTop: -5
                                },
                                className: "notification-badge",
                                color: "danger"
                            }, this.state.notificationAlert)), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav notificationList",
                                "aria-labelledby": "notification"
                            }, this.state.notificationList.length > 0 ? this.state.notificationList.map((function(e, a) {
                                return i.a.createElement(m.b, {
                                    to: 3 === e.type && 0 !== e.link_id ? "/reports/details/" + e.link_id : 4 === e.type && 0 !== e.link_id ? "/tickets/details/" + e.link_id : 2 === e.type ? "/notification" : "#"
                                }, i.a.createElement("li", {
                                    className: 2 === e.type ? "adminNotif" : ""
                                }, i.a.createElement("span", {
                                    dir: "ltr"
                                }, e.message), i.a.createElement("div", {
                                    className: "notifDate"
                                }, e.created_at)))
                            })) : i.a.createElement("li", null, "No notification")))))))))
                        }
                    }, {
                        key: "readNotif",
                        value: function() {
                            document.getElementsByClassName("notification-badge")[0].innerHTML = 0, localStorage.removeItem("notificationAlert"), S.a.NetworkingRequest("POST", "webservice/v1/readNotif", {
                                api_token: localStorage.getItem("apiToken")
                            }).then((function(e) {}))
                        }
                    }]), t
                }(s.Component),
                M = function(e) {
                    Object(o.a)(t, e);
                    var a = Object(c.a)(t);

                    function t(e) {
                        var l;
                        return Object(n.a)(this, t), l = a.call(this, e), Object(r.a)(l), l.toggle = l.toggle.bind(Object(r.a)(l)), l.state = {
                            categoryList: [],
                            isOpen: !1,
                            contactInfo: []
                        }, l
                    }
                    return Object(l.a)(t, [{
                        key: "toggle",
                        value: function() {
                            this.setState({
                                isOpen: !this.state.isOpen
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return i.a.createElement(i.a.Fragment, null, i.a.createElement("div", {
                                className: "header"
                            }, i.a.createElement(f.a, null, i.a.createElement(h.a, {
                                xs: "5"
                            }, i.a.createElement(D.a, {
                                id: "mobile-category-bar",
                                className: " category-toggler mobile-category-bar"
                            }, i.a.createElement("span", null, i.a.createElement("i", {
                                className: "fa fa-bars"
                            }), " ")), i.a.createElement(x, {
                                style: {
                                    color: "#fff",
                                    marginLeft: 8
                                },
                                href: "/"
                            }, "FreshTools")), i.a.createElement(h.a, {
                                className: "p-1",
                                xs: "7"
                            }, i.a.createElement("ul", {
                                className: "header-nav"
                            }, i.a.createElement("li", {
                                className: "dropdown"
                            }, i.a.createElement("a", {
                                className: "dropdown-toggle",
                                href: "#",
                                id: "AccountDropDown",
                                "data-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false"
                            }, i.a.createElement("span", null, "Account"), i.a.createElement("i", {
                                className: "flaticon-user"
                            })), i.a.createElement("ul", {
                                className: "dropdown-menu header-nav drop-nav",
                                "aria-labelledby": "AccountDropDown"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/profile"
                            }, i.a.createElement("span", null, "Setting"), i.a.createElement("i", {
                                className: "fas fa-user-cog fa-fw"
                            }))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/orders"
                            }, i.a.createElement("span", null, "My Orders"), i.a.createElement("i", {
                                className: "fas fa-shopping-cart fa-fw"
                            }))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/AddBalance"
                            }, i.a.createElement("span", null, "Add Balance"), i.a.createElement("i", {
                                className: "fas fa-dollar-sign fa-fw"
                            }))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/notification"
                            }, i.a.createElement("span", null, "Inbox"), i.a.createElement("i", {
                                className: "fas fa-inbox fa-fw"
                            }))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/",
                                onClick: function() {
                                    localStorage.removeItem("apiToken"), localStorage.removeItem("sellerInventory"), localStorage.removeItem("sellerApiToken")
                                }
                            }, i.a.createElement("span", null, "Logout"), i.a.createElement("i", {
                                className: "fas fa-sign-out-alt fa-fw"
                            }))))), i.a.createElement("li", null, i.a.createElement("a", {
                                className: "add-balance",
                                href: "/AddBalance"
                            }, i.a.createElement("i", {
                                className: "fas fa-plus-circle"
                            }), i.a.createElement("span", null, localStorage.getItem("inventory")))))))), i.a.createElement("div", {
                                className: "overlay"
                            }))
                        }
                    }]), t
                }(s.Component),
                L = (t(10), ""),
                A = function(e) {
                    Object(o.a)(t, e);
                    var a = Object(c.a)(t);

                    function t(e) {
                        var l;
                        return Object(n.a)(this, t), l = a.call(this, e), L = Object(r.a)(l), l.state = {
                            width: 0,
                            height: 0
                        }, l
                    }
                    return Object(l.a)(t, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = document.createElement("script");
                            e.src = "/assets/js/jquery.floatThead.js", document.body.appendChild(e);
                            var a = document.createElement("script");
                            a.src = "/assets/js/mainJS.js", document.body.appendChild(a), L.updateWindowDimensions(), window.addEventListener("resize", L.updateWindowDimensions)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            window.removeEventListener("resize", L.updateWindowDimensions)
                        }
                    }, {
                        key: "updateWindowDimensions",
                        value: function() {
                            L.setState({
                                width: window.innerWidth,
                                height: window.innerHeight
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this.state.width <= 700 ? i.a.createElement(M, null) : i.a.createElement(P, null)
                        }
                    }]), t
                }(s.Component),
                I = i.a.lazy((function() {
                    return Promise.all([t.e(27), t.e(25)]).then(t.bind(null, 203))
                })),
                R = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(11), t.e(39)]).then(t.bind(null, 177))
                })),
                W = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(12), t.e(44)]).then(t.bind(null, 180))
                })),
                _ = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(14), t.e(48)]).then(t.bind(null, 181))
                })),
                B = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(13), t.e(45)]).then(t.bind(null, 182))
                })),
                F = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(8), t.e(43)]).then(t.bind(null, 183))
                })),
                q = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(9), t.e(46)]).then(t.bind(null, 184))
                })),
                H = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(10), t.e(41)]).then(t.bind(null, 185))
                })),
                J = i.a.lazy((function() {
                    return t.e(31).then(t.bind(null, 186))
                })),
                V = i.a.lazy((function() {
                    return Promise.all([t.e(4), t.e(35)]).then(t.bind(null, 187))
                })),
                G = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(3), t.e(28), t.e(42)]).then(t.bind(null, 189))
                })),
                U = i.a.lazy((function() {
                    return Promise.all([t.e(21), t.e(36)]).then(t.bind(null, 190))
                })),
                K = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(4), t.e(47)]).then(t.bind(null, 191))
                })),
                Q = i.a.lazy((function() {
                    return t.e(33).then(t.bind(null, 103))
                })),
                X = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(22)]).then(t.bind(null, 192))
                })),
                Y = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(15), t.e(49)]).then(t.bind(null, 193))
                })),
                Z = i.a.lazy((function() {
                    return Promise.all([t.e(16), t.e(34)]).then(t.bind(null, 194))
                })),
                $ = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(3), t.e(32)]).then(t.bind(null, 204))
                })),
                ee = i.a.lazy((function() {
                    return t.e(30).then(t.bind(null, 104))
                })),
                ae = i.a.lazy((function() {
                    return t.e(29).then(t.bind(null, 195))
                })),
                te = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(17), t.e(50)]).then(t.bind(null, 196))
                })),
                ne = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(18), t.e(37)]).then(t.bind(null, 197))
                })),
                le = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(19), t.e(38)]).then(t.bind(null, 198))
                })),
                re = i.a.lazy((function() {
                    return Promise.all([t.e(0), t.e(20), t.e(40)]).then(t.bind(null, 199))
                })),
                oe = [{
                    path: "/",
                    exact: !0,
                    name: "home",
                    component: I
                }, {
                    path: "/cpanelList",
                    exact: !0,
                    name: "cpanel",
                    component: R
                }, {
                    path: "/ssh",
                    exact: !0,
                    name: "VpsList",
                    component: _
                }, {
                    path: "/rdp",
                    exact: !0,
                    name: "RdpList",
                    component: W
                }, {
                    path: "/shell",
                    exact: !0,
                    name: "ShellList",
                    component: B
                }, {
                    path: "/phpMailers",
                    exact: !0,
                    name: "phpMailers",
                    component: F
                }, {
                    path: "/smtp",
                    exact: !0,
                    name: "Smtp",
                    component: q
                }, {
                    path: "/leads",
                    exact: !0,
                    name: "Leads",
                    component: H
                }, {
                    path: "/reports",
                    exact: !0,
                    name: "ReportList",
                    component: J
                }, {
                    path: "/reports/details/:report_id",
                    exact: !0,
                    name: "ReporDetails",
                    component: V
                }, {
                    path: "/reports/order/:order_id",
                    exact: !0,
                    name: "ReporDetails",
                    component: V
                }, {
                    path: "/orders",
                    exact: !0,
                    name: "orders",
                    component: G
                }, {
                    path: "/tickets",
                    exact: !0,
                    name: "TicketList",
                    component: U
                }, {
                    path: "/tickets/add",
                    exact: !0,
                    name: "TicketAdd",
                    component: Q
                }, {
                    path: "/tickets/details/:ticket_id",
                    exact: !0,
                    name: "TicketDetails",
                    component: K
                }, {
                    path: "/profile",
                    exact: !0,
                    name: "Profile",
                    component: X
                }, {
                    path: "/vip",
                    exact: !0,
                    name: "Vip",
                    component: Y
                }, {
                    path: "/AddBalance",
                    exact: !0,
                    name: "AddBalance",
                    component: Z
                }, {
                    path: "/AddBalance/:type",
                    exact: !0,
                    name: "AddBalance",
                    component: Z
                }, {
                    path: "/payment/:token",
                    exact: !0,
                    name: "Payment",
                    component: $
                }, {
                    path: "/lastDeposit",
                    exact: !0,
                    name: "lastDeposit",
                    component: ee
                }, {
                    path: "/earnMoney",
                    exact: !0,
                    name: "EarnMoney",
                    component: ae
                }, {
                    path: "/webMail",
                    exact: !0,
                    name: "Webmail",
                    component: te
                }, {
                    path: "/accounts",
                    exact: !0,
                    name: "accounts",
                    component: ne
                }, {
                    path: "/notification",
                    exact: !0,
                    name: "notification",
                    component: i.a.lazy((function() {
                        return Promise.all([t.e(0), t.e(26)]).then(t.bind(null, 200))
                    }))
                }, {
                    path: "/bankaccount",
                    exact: !0,
                    name: "Bank",
                    component: le
                }, {
                    path: "/fullz",
                    exact: !0,
                    name: "Fullz",
                    component: re
                }],
                ce = (s.Component, function(e) {
                    Object(o.a)(t, e);
                    var a = Object(c.a)(t);

                    function t(e) {
                        var l;
                        return Object(n.a)(this, t), l = a.call(this, e), Object(r.a)(l), l.state = {
                            width: 0,
                            height: 0
                        }, l
                    }
                    return Object(l.a)(t, [{
                        key: "render",
                        value: function() {
                            return i.a.createElement("div", null)
                        }
                    }]), t
                }(s.Component)),
                se = function(e) {
                    Object(o.a)(t, e);
                    var a = Object(c.a)(t);

                    function t() {
                        return Object(n.a)(this, t), a.apply(this, arguments)
                    }
                    return Object(l.a)(t, [{
                        key: "render",
                        value: function() {
                            return i.a.createElement("ul", {
                                className: "sidebar-list"
                            }, i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/panel"
                            }, i.a.createElement("i", {
                                className: "flaticon-speedometer"
                            }), i.a.createElement("span", null, "Dashboard"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/orders"
                            }, i.a.createElement("i", {
                                className: "flaticon-shopping-cart"
                            }), i.a.createElement("span", null, "Orders"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/rdp"
                            }, i.a.createElement("i", {
                                className: "flaticon-backend"
                            }), i.a.createElement("span", null, "Rdps"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/cpanelList"
                            }, i.a.createElement("i", {
                                className: "flaticon-tools"
                            }), i.a.createElement("span", null, "Cpanel"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/ssh"
                            }, i.a.createElement("i", {
                                className: "flaticon-setting"
                            }), i.a.createElement("span", null, "SSH"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/webMail"
                            }, i.a.createElement("i", {
                                className: "flaticon-setting"
                            }), i.a.createElement("span", null, "webmail"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/shell"
                            }, i.a.createElement("i", {
                                className: "flaticon-web-programming"
                            }), i.a.createElement("span", null, "Shells"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/phpMailers"
                            }, i.a.createElement("i", {
                                className: "flaticon-inbox"
                            }), i.a.createElement("span", null, "Php Mailers"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/smtp"
                            }, i.a.createElement("i", {
                                className: "flaticon-email"
                            }), i.a.createElement("span", null, "Smtps"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/leads"
                            }, i.a.createElement("i", {
                                className: "flaticon-address"
                            }), i.a.createElement("span", null, "Leads"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/vip"
                            }, i.a.createElement("i", {
                                className: "fa fa-user-secret"
                            }), i.a.createElement("span", null, "Vip Section"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/bankaccount"
                            }, i.a.createElement("i", {
                                className: "fa fa-university"
                            }), i.a.createElement("span", null, "Bank Account"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/fullz"
                            }, i.a.createElement("i", {
                                className: "fa fa-university"
                            }), i.a.createElement("span", null, "CC / Fullz"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/accounts"
                            }, i.a.createElement("i", {
                                className: "fa fa-users"
                            }), i.a.createElement("span", null, "Accounts"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/tickets"
                            }, i.a.createElement("i", {
                                className: "flaticon-question"
                            }), i.a.createElement("span", null, "Ticket"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/reports"
                            }, i.a.createElement("i", {
                                className: "flaticon-bot"
                            }), i.a.createElement("span", null, "Report"))), i.a.createElement("li", null, i.a.createElement("a", {
                                href: "/",
                                onClick: function() {
                                    localStorage.removeItem("apiToken")
                                }
                            }, i.a.createElement("i", {
                                className: "fa fa-sign-out"
                            }), i.a.createElement("span", null, "Logout"))))
                        }
                    }]), t
                }(s.Component),
                ie = function(e) {
                    Object(o.a)(t, e);
                    var a = Object(c.a)(t);

                    function t(e) {
                        var l;
                        return Object(n.a)(this, t), l = a.call(this, e), Object(r.a)(l), l.state = {
                            width: 0,
                            height: 0
                        }, l
                    }
                    return Object(l.a)(t, [{
                        key: "render",
                        value: function() {
                            return i.a.createElement(p.a, {
                                className: "shadow-sm mobile-sidebar"
                            }, i.a.createElement(d.a, null, i.a.createElement(se, null)))
                        }
                    }]), t
                }(s.Component),
                ue = "",
                me = function(e) {
                    Object(o.a)(t, e);
                    var a = Object(c.a)(t);

                    function t(e) {
                        var l;
                        return Object(n.a)(this, t), l = a.call(this, e), ue = Object(r.a)(l), l.state = {
                            width: 0,
                            height: 0
                        }, l
                    }
                    return Object(l.a)(t, [{
                        key: "componentDidMount",
                        value: function() {
                            ue.updateWindowDimensions(), window.addEventListener("resize", ue.updateWindowDimensions)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            window.removeEventListener("resize", ue.updateWindowDimensions)
                        }
                    }, {
                        key: "updateWindowDimensions",
                        value: function() {
                            ue.setState({
                                width: window.innerWidth,
                                height: window.innerHeight
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return ue.state.width <= 768 ? i.a.createElement(ie, null) : i.a.createElement(ce, null)
                        }
                    }]), t
                }(s.Component),
                pe = function(e) {
                    Object(o.a)(t, e);
                    var a = Object(c.a)(t);

                    function t(e) {
                        var l;
                        return Object(n.a)(this, t), l = a.call(this, e), j = Object(r.a)(l), l.state = {
                            width: 0,
                            height: 0
                        }, l
                    }
                    return Object(l.a)(t, [{
                        key: "componentDidMount",
                        value: function() {
                            null !== localStorage.getItem("apiToken") && "" !== localStorage.getItem("apiToken") || (window.location.href = "/login");
                            var e = {
                                api_token: localStorage.getItem("apiToken")
                            };
                            S.a.NetworkingRequest("POST", "webservice/v1/dashboard", e).then((function(e) {
                                "success" === e.status ? (localStorage.setItem("productCount", JSON.stringify(e.response.ProductCount)), localStorage.setItem("inventory", e.response.inventory)) : j.setState({
                                    loading: !1
                                })
                            }))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return i.a.createElement("div", {
                                className: "userPanelBackground"
                            }, i.a.createElement(A, null), i.a.createElement("div", null, i.a.createElement(u.d, null, oe.map((function(e, a) {
                                return e.component ? i.a.createElement(u.b, {
                                    key: a,
                                    path: e.path,
                                    exact: e.exact,
                                    name: e.name,
                                    render: function(a) {
                                        return i.a.createElement(e.component, a)
                                    }
                                }) : null
                            })), i.a.createElement(u.a, {
                                from: "/",
                                to: "/404"
                            }))), i.a.createElement(me, null), i.a.createElement("div", {
                                className: "overlay"
                            }))
                        }
                    }]), t
                }(s.Component);
            a.default = pe
        },
        49: function(e, a, t) {
            "use strict";
            var n = t(9),
                l = t.n(n),
                r = t(20),
                o = t(14),
                c = t(15),
                s = (t(0), t(66)),
                i = t.n(s),
                u = t(61),
                m = (t(67), function() {
                    function e() {
                        Object(o.a)(this, e)
                    }
                    return Object(c.a)(e, null, [{
                        key: "NetworkingRequest",
                        value: function() {
                            var e = Object(r.a)(l.a.mark((function e(a, t, n) {
                                return l.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", window.fetch(u.a.api_url + t, {
                                                method: a,
                                                headers: {
                                                    "Content-Type": "application/json"
                                                },
                                                body: JSON.stringify(n)
                                            }).then((function(e) {
                                                return e.json()
                                            })).then((function(e) {
                                                return e
                                            })).catch((function(e) {
                                                return console.log(e)
                                            })));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(a, t, n) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        key: "NetworkingRequestFormData",
                        value: function() {
                            var e = Object(r.a)(l.a.mark((function e(a, t, n) {
                                var r;
                                return l.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return r = {
                                                headers: {
                                                    "content-type": "multipart/form-data"
                                                }
                                            }, e.abrupt("return", i.a.post(u.a.api_url + t, n, r).then((function(e) {
                                                return e.data
                                            })).catch((function(e) {
                                                console.log(e)
                                            })));
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(a, t, n) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }]), e
                }());
            a.a = m
        },
        61: function(e, a, t) {
            "use strict";
            a.a = {
                base_url: "https://freshtools.net",
                base_url_file: "https://freshtools.net/uploads/",
                api_url: " https://freshtools.net/rest/api/"
            }
        }
    }
]);
//# sourceMappingURL=24.5bf4e7b1.chunk.js.map